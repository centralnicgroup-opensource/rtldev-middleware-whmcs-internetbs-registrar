# 1.0.0 (2021-08-23)


### Bug Fixes

* **upgrade:** fixed a few issues and added an upograde sql script to migrate from old or bundled module version to this new one ([a25964f](https://github.com/internetbs/whmcs-internetbs-registrar/commit/a25964fb8f2b654223ce1945810d229500deddc7))
* **whmcs.json:** fixed invalid json ([0c88c31](https://github.com/internetbs/whmcs-internetbs-registrar/commit/0c88c31173aa1b8a64b404970bace468fad64484))


### Features

* **release automation:** initial version ([fe5bb47](https://github.com/internetbs/whmcs-internetbs-registrar/commit/fe5bb47622f9059a0219c1636ba16d0a7067b3be))
