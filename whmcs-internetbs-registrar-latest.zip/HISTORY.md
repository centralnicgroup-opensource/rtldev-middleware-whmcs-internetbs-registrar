## [1.0.2](https://github.com/internetbs/whmcs-internetbs-registrar/compare/v1.0.1...v1.0.2) (2022-06-10)


### Bug Fixes

* **cart & renewals:** cart timeouts, special renewal issues ([278f227](https://github.com/internetbs/whmcs-internetbs-registrar/commit/278f227324437257f6ef527b83c42f93a44acb6d))

## [1.0.1](https://github.com/internetbs/whmcs-internetbs-registrar/compare/v1.0.0...v1.0.1) (2021-11-25)


### Bug Fixes

* **registrar tld sync:** Modified the price sync to check the defaut currency of the WHMCS installation and, if that currency is supported by us, pull the prices in that currency ([3e66f13](https://github.com/internetbs/whmcs-internetbs-registrar/commit/3e66f1385753741b8487ef07b5cbb640a1471717))

# 1.0.0 (2021-08-23)


### Bug Fixes

* **upgrade:** fixed a few issues and added an upograde sql script to migrate from old or bundled module version to this new one ([a25964f](https://github.com/internetbs/whmcs-internetbs-registrar/commit/a25964fb8f2b654223ce1945810d229500deddc7))
* **whmcs.json:** fixed invalid json ([0c88c31](https://github.com/internetbs/whmcs-internetbs-registrar/commit/0c88c31173aa1b8a64b404970bace468fad64484))


### Features

* **release automation:** initial version ([fe5bb47](https://github.com/internetbs/whmcs-internetbs-registrar/commit/fe5bb47622f9059a0219c1636ba16d0a7067b3be))
